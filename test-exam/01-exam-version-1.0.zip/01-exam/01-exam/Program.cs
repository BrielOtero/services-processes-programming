﻿namespace _01_exam
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Drones drones= new Drones();
        }
    }
}